# Nusuk DL · patterns and templates

From the Nusuk Design Language, release 2026-11-17. Start with `templates-and-patterns.md` (the method), pick a contract by job in `templates/index.json`, read that one file in `templates/contracts/`, and fill its spaces with the patterns in `patterns/index.json`. Full text of every contract: `template-contracts.md`. The rules behind them: DESIGN.md › M9S, M9T and M9P.
